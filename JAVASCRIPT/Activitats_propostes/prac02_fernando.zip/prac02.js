document.write("<h3 id='titol3'>Hola, ací comencem en JavaScript.</h3>");
alert("Benvingut a la segona pràctica.");
document.getElementById("titol1").innerHTML = "<h3 id='titol3'>Sóc Fernando i estic modificant aquest missatge.</h3>";
console.log("Fernando Aleixos");
console.log("04/03/2022");
document.write("<h3>Fins prompte!</h3>");