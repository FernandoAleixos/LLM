function hola() {
    console.log("Hola");
}

function meLlamo() {
    console.log("Me llamo Fernando.");
}

function diaActual() {
    alert("Huy estem a 01/03/2022.");
}

function terminando() {
    console.log("Estoy terminando la práctica.");
}

function borrar() {
    console.clear();
}

hola();
meLlamo();
