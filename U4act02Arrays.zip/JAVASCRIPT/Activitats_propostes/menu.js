function suma(valor1, valor2) {
    return valor1 + valor2;
}

function resta(num1, num2) {
    return num1 - num2;
}

function multiplicacio(num1, num2) {
    return num1 * num2;
}

function divisio(num1, num2) {
    return num1 / num2;
}